const genApiKey = require("./genApiKey");

console.log(genApiKey(100))