module.exports = {
    database: {
        filename: "db_glo_decrypted.db"
    },
    api: {
        rootName: "api",
        port: 25607,
        cors: {
            allowedDomains:  ["http://localhost:3000"]
        }
    }
}